import java.io.*;
import java.util.*;
import java.util.Calendar;
class Doctor {
        private static Scanner x;
        String dr_ID, dr_Name, specialist, appoint, dr_qualification;
        int dr_room;
        void new_doctor()
        {
            Scanner input = new Scanner(System.in);
            System.out.print("Enter doctor id:-");
            dr_ID = input.nextLine();
            System.out.print("Enter name of the doctor:-");
            dr_Name = input.nextLine();
            System.out.print("Doctor's specialization:-");
            specialist = input.nextLine();
            System.out.print("work time:-");
            appoint = input.nextLine();
            System.out.print("qualification:-");
            dr_qualification = input.nextLine();
            System.out.print("room no.:-");
            dr_room = input.nextInt();

            try
            {
                File file = new File("DoctorsList.txt");
                PrintWriter pw=new PrintWriter(new FileOutputStream(file,true));
                pw.append(dr_ID+","+dr_Name+","+specialist+","+appoint+","+dr_qualification+","+dr_room+"\n");
                pw.close();
            }
            catch(Exception e){
                System.out.println("An error occurred");
                e.printStackTrace();
            }
        }
        void display()
        {
            try
            {
                File file = new File("DoctorsList.txt");
                Scanner myReader=new Scanner(file);
                while(myReader.hasNextLine()){
                    String data=myReader.nextLine();
                    System.out.println(data);
                }
                myReader.close();
            }
            catch(FileNotFoundException e){
                System.out.println("An error occurred");
                e.printStackTrace();
            }
        }
        
    public static void delete_details( )
    {
        Scanner input=new Scanner(System.in);
        System.out.println("Enter the doctor id to delete it from file: ");
        String removeTerm=input.nextLine();
        String tempFile="temp.txt";
        String Filepath="DoctorsList.txt";
        File oldFile=new File(Filepath);
        File newFile=new File(tempFile);
        String ID="";String name="";String s="";String t="";String q="";String r="";
        try {
            FileWriter fw=new FileWriter(tempFile,true);
            BufferedWriter bw=new BufferedWriter(fw);
            PrintWriter pw=new PrintWriter(bw);

            x=new Scanner(new File(Filepath));
            x.useDelimiter("[,\n]");

            while(x.hasNext())
            {
                ID=x.next();
                name=x.next();
                s=x.next();
                t=x.next();
                q=x.next();
                r=x.next();
                if(!ID.equals(removeTerm))
                {
                    pw.println(ID + "," + name + "," + s+ "," +t+ "," +q+ "," +r);
                }
            }
            x.close();
            pw.flush();
            pw.close();

            oldFile.delete();
            File dump=new File(Filepath);
            newFile.renameTo(dump);
        }
        catch(Exception e){
        }
    }
    }

class Main
{
    public static void main(String args[])
    {
        String months[] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
        Calendar calendar = Calendar.getInstance();
        //System.out.println("--------------------------------------------------------------------------------");
        System.out.println("\n--------------------------------------------------------------------------------");
        System.out.println("            *** Welcome to Hospital Management System Project in Java ***");
        System.out.println("--------------------------------------------------------------------------------");
        System.out.print("Date: " + months[calendar.get(Calendar.MONTH)] + " " + calendar.get(Calendar.DATE) + " " + calendar.get(Calendar.YEAR));
        System.out.println("\t\t\t\t\t\tTime: " + calendar.get(Calendar.HOUR) + ":" + calendar.get(Calendar.MINUTE) + ":" + calendar.get(Calendar.SECOND));
        Doctor d = new Doctor();
        Scanner input = new Scanner(System.in);
        int choice, j, c1, status = 1, s1 = 1;
        while (status == 1)
        {
            System.out.println("\n                                    MAIN MENU");
            System.out.println("-----------------------------------------------------------------------------------");
            System.out.println("1.Doctors  2. Patients  3.Staff  4.Laboratories  5. Facilities  6. Medicines ");
            System.out.println("-----------------------------------------------------------------------------------");
            choice = input.nextInt();
            switch (choice)
            {
                case 1:
                {
                    System.out.println("--------------------------------------------------------------------------------");
                    System.out.println("                      **DOCTOR SECTION**");
                    System.out.println("--------------------------------------------------------------------------------");
                    s1 = 1;
                    while (s1 == 1)
                    {
                        System.out.println("1.Add New Entry\n2.Existing Doctors List\n3.Delete doctor's info");
                        c1 = input.nextInt();
                        switch (c1)
                        {
                            case 1:
                            {
                                d.new_doctor();
                                break;
                            }
                            case 2:
                            {
                                d.display();
                                break;
                            }
                          
                            case 3:{
                                d.delete_details();
                                break;
                            }
                        }
                        System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                        s1 = input.nextInt();
                    }
                    break;
                }
                /*
                case 2:
                {
                    System.out.println("--------------------------------------------------------------------------------");
                    System.out.println("                     **PATIENT SECTION**");
                    System.out.println("--------------------------------------------------------------------------------");
                    int s2 = 1;
                    while (s2 == 1)
                    {
                        System.out.println("1.Add New Entry\n2.Existing Patients List\n3.Update any info\n4.Delete patient's info");
                        c1 = input.nextInt();
                        switch (c1)
                        {
                            case 1:
                            {
                                p.new_patient();
                                break;
                            }
                            case 2:
                            {
                                p.display();
                                break;
                            }
                            case 3:{
                                p.update_details();
                                break;
                            }
                            case 4:{
                                p.delete_details();
                                break;
                            }
                        }
                        System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                        s2 = input.nextInt();
                    }
                    break;
                }
                /*
                case 3:
                {
                    int s3 = 1;
                    System.out.println("--------------------------------------------------------------------------------");
                    System.out.println("                       **STAFF SECTION**");
                    System.out.println("--------------------------------------------------------------------------------");
                    while (s3 == 1)
                    {
                        String a = "nurse", b = "worker", c = "security";
                        System.out.println("1.Add New Entry \n2.Existing Nurses List\n3.Existing Workers List \n4.Existing Security List");
                        c1 = input.nextInt();
                        switch (c1)
                        {
                            case 1:
                            {
                                s.new_staff();
                                break;
                            }
                            case 2:
                            {
                                s.nurses_list();
                                break;
                            }
                            case 3:
                            {
                                s.workers_list();
                                break;
                            }
                            case 4:
                            {
                                s.security_list();
                                break;
                            }
                        }
                        System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                        s3= input.nextInt();
                    }
                    break;
                }*/
                default:
                {
                    System.out.println(" You Have Enter Wrong Choice!!!");
                }
            }
            System.out.println("\nReturn to MAIN MENU Press 1");
            status = input.nextInt();
        }
    }
}

